#ifndef YIGIN_H
#define YIGIN_H

#include <stack>
#include <string>
#include <ctime>
#include "ortak.h"
using namespace std;

void kitapOduncAl(kitap* bas);
void kitapIadeEt(kitap* bas);
void oduncAlinanlariListele(kitap* bas);
void iadeEdilenleriListele(kitap* bas);

#endif
