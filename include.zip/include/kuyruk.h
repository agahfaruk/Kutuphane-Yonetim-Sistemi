#ifndef KUYRUK_H
#define KUYRUK_H

#include <string>
#include <iostream>
#include <queue>
#include <cstdlib>
#include <windows.h>
#include <ctime>
#include <algorithm>
#include <map>
#include "ortak.h"
using namespace std;

void talepYonetimi(kitap*& bas);
void talepEkle();
void akademikTalepEkle();
void talepleriListele();

#endif