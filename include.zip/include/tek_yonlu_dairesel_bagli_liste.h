#ifndef TEK_YONLU_DAIRESEL_BAGLI_LISTE_H
#define TEK_YONLU_DAIRESEL_BAGLI_LISTE_H

#include <string>
#include "ortak.h"
using namespace std;

void oduncRaporuGoster(kitap* bas);
void iadeRaporuGoster(kitap* bas);
void erisilebilirKitaplariGoster(kitap* bas);

#endif